const express = require("express");
// const cors = require("cors");
const config = require("./configs/app");
const logger = require("./configs/logger");
const app = express();

// CORS
// app.use(cors());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*"); // Allow requests from any origin
  // You can specify specific origins instead of '*' if needed
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  next();
});

// Connect database
require("./configs/databases");

// Body parser
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: false, limit: "50mb" }));

// Passport
require("./configs/passport");

// Custom Response Format
app.use(require("./configs/responseFormat"));

// Middleware
require("./configs/middleware");

// Routes
app.use(require("./routes"));

// Error handler
require("./configs/errorHandler")(config.isProduction, app);

// Start Server
const server = app
  .listen(config.port, "192.168.0.199", () => {
    // .listen(config.port, "127.0.0.1", () => {
    // For IpV6
    // .listen(config.port, () => { // For IpV4
    let host = server.address().address;
    let port = server.address().port;
    console.log(`Server is running on http://${host}:${port}`);
  })
  .on("error", function (err) {
    logger.error("[start server error]:");
    logger.error(JSON.stringify(err));
  });
